<header id="header" class="border-bottom-0 no-sticky transparent-header">
    <div id="header-wrap">
        <div class="container">
            <div class="header-row">

                <!-- Logo
                ============================================= -->
                <div id="logo">
                    <a href="<?php echo e(route('front')); ?>" class="standard-logo">
                        <img src="<?php echo e(getAdminSettingValue('company_logo')); ?>" alt="InfyPortfolio Logo" class="h-50">
                    </a>
                    <a href="demo-freelancer.html" class="retina-logo">
                        <img src="<?php echo e(getAdminSettingValue('company_logo')); ?>" alt="InfyPortfolio Logo"
                             class="h-50 mt-2">
                    </a>
                </div><!-- #logo end -->

                <div class="header-misc">
                    <a href="mailto:noreply@canvas.com" class="button button-border rounded-pill">Email Us</a>
                </div>

                <div id="primary-menu-trigger">
                    <svg class="svg-trigger" viewBox="0 0 100 100">
                        <path d="m 30,33 h 40 c 3.722839,0 7.5,3.126468 7.5,8.578427 0,5.451959 -2.727029,8.421573 -7.5,8.421573 h -20"></path>
                        <path d="m 30,50 h 40"></path>
                        <path d="m 70,67 h -40 c 0,0 -7.5,-0.802118 -7.5,-8.365747 0,-7.563629 7.5,-8.634253 7.5,-8.634253 h 20"></path>
                    </svg>
                </div>

                <!-- Primary Navigation
                ============================================= -->
                <nav class="primary-menu">

                    <ul class="menu-container">
                        <li class="menu-item"><a class="menu-link" href="demo-freelancer-about.html">
                                <div>About me</div>
                            </a></li>
                        <li class="menu-item"><a class="menu-link" href="demo-freelancer-works.html">
                                <div>Works</div>
                            </a></li>
                        <li class="menu-item"><a class="menu-link" href="#" data-scrollto="#footer"
                                                 data-easing="easeInOutExpo" data-speed="1250" data-offset="70">
                                <div>Contact</div>
                            </a></li>
                    </ul>

                </nav><!-- #primary-menu end -->

            </div>
        </div>
    </div>
</header>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/front/header.blade.php ENDPATH**/ ?>