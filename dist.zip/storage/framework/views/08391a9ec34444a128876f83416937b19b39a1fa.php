<div class="modal fade p-0 hire-me-modal" id="hireMeModal" tabindex="-1" role="dialog" aria-labelledby="hireMeModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title " id="hireMeModalLabel"> Hire Me</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo e(Form::open(['id' =>'hireMeForm','method'=>'post', 'autocomplete'=>'off'])); ?>

                <div class="row">
                    <div class="form-group col-lg-4 col-12">
                        <?php echo e(Form::label('name', 'Name:')); ?><span class="text-danger">*</span>
                        <?php echo e(Form::text('name', null , ['class' => 'form-control','placeholder' => 'Enter Name','required'])); ?>

                    </div>
                    <div class="form-group col-lg-4 col-12">
                        <?php echo e(Form::label('email', 'Email:')); ?><span class="text-danger">*</span>
                        <?php echo e(Form::email('email', null , ['class' => 'form-control','placeholder' => 'Enter Email','required'])); ?>

                    </div>
                    <div class="form-group col-lg-4 col-12">
                        <?php echo e(Form::label('mobile', 'Mobile:')); ?>

                        <?php echo e(Form::text('mobile', null,['class' => 'form-control', 'onkeyup' => 'if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,"")','id'=>'phoneNumber','placeholder' => 'Enter Mobile Number','minlength'=> '10','maxlength'=> '10'])); ?>

                        
                        
                        
                    </div>
                    <div class="form-group col-lg-4 col-12">
                        <?php echo e(Form::label('company_name', 'Company Name:')); ?><span class="text-danger">*</span>
                        <?php echo e(Form::text('company_name', null , ['class' => 'form-control','placeholder' => 'Enter Company Name','required'])); ?>

                    </div>
                    <div class="form-group col-lg-4 col-12">
                        <?php echo e(Form::label('interested in', 'Interested In:')); ?><span class="text-danger">*</span>
                        <?php echo e(Form::text('interested_in', null , ['class' => 'form-control','placeholder' => 'Enter Interest','required'])); ?>

                    </div>
                    <div class="form-group col-lg-4 col-12">
                        <?php echo e(Form::label('budget', 'Budget:')); ?><span class="text-danger">*</span>
                        <?php echo e(Form::text('budget', null , ['class' => 'form-control','placeholder' => 'Enter Budget', 'required', 'onkeyup' => 'if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,"")'])); ?>

                    </div>
                    <div class="form-group col-12">
                        <?php echo e(Form::label('message', 'Message:')); ?><span class="text-danger">*</span>
                        <?php echo e(Form::textarea('message', null , ['class' => 'form-control','id'=>'message','placeholder' => 'Enter Message'])); ?>

                    </div>
                </div>
                <?php echo e(Form::button('Save', ['type' => 'submit', 'class' => 'btn hire-me-btn', 'id' => 'hireMeSaveBtn', 'data-loading-text' => "<span class='spinner-border spinner-border-sm'></span> Processing..."])); ?>

                <?php echo e(Form::button('Cancel', ['type' => 'button', 'class' => 'btn hire-me-cancel-btn text-dark','data-dismiss'=>'modal'])); ?>

                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/hire_me/create_model.blade.php ENDPATH**/ ?>