<div class="row">
    <div class="form-group col-md-6">
        <?php echo e(Form::label('first_name', __('messages.first_name').':')); ?><span class="text-danger">*</span>
        <?php echo e(Form::text('first_name', null, ['class' => 'form-control', 'maxlength' => 255, 'required', 'placeholder' =>  __('messages.enter_first_name')])); ?>

    </div>

    <div class="form-group col-md-6">
        <?php echo e(Form::label('first_name', __('messages.last_name').':')); ?><span class="text-danger">*</span>
        <?php echo e(Form::text('last_name', null, ['class' => 'form-control', 'maxlength' => 255, 'required', 'placeholder' => __('messages.enter_last_name')])); ?>

    </div>










    <div class="col-md-6">
        <?php echo e(Form::label('phone', __('messages.phone').':')); ?><span class="text-danger">*</span>
        <div class="d-flex">
            <div class="region-code">
                <button type="button" class="btn btn-default mr-0 f16 dropdown-toggle region-code-button"
                        id="dropdownMenuButton" data-toggle="dropdown">
                    <span class="flag <?php echo e((isset($user) && !empty($user->region_code_flag)) ? $user->region_code_flag : 'in'); ?>"
                          id="btnFlag"></span>
                    <span class="btn-cc">&nbsp;&nbsp;<?php echo e(isset($user) && !empty($user->region_code) ? '+'.$user->region_code : '+91'); ?>&nbsp;&nbsp;</span>
                    <span class="caretButton"></span>
                </button>
                <div class="region-code-div" aria-labelledby="dropdownMenuButton">
                    <ul class="f16 dropdown-menu region-code-ul">
                        <div class="region-code-ul-input-div"><input type="text" class="form-control search-country"/>
                        </div>
                        <div class="region-code-ul-div"></div>
                    </ul>
                </div>
            </div>
            <input type="tel" class="form-control" name="phone" id="phoneNumber"
                   value="<?php echo e(isset($user) ? $user->phone :null); ?>"
                   onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" required/>
            <input type="hidden" name="region_code" id="regionCode"
                   value="<?php echo e(isset($user) && !empty($user->region_code) ? $user->region_code : 91); ?>"/>
            <input type="hidden" name="region_code_flag" id="regionCodeFlag"
                   value="<?php echo e(isset($user) ? $user->region_code_flag : null); ?>"/>
            <span id="valid-msg" class="hide">✓ &nbsp; Valid</span>
            <span id="error-msg" class="hide"></span>
        </div>
    </div>


    <div class="form-group col-md-6">
        <?php echo e(Form::label('email', __('messages.email').':')); ?><span class="text-danger">*</span>
        <?php echo e(Form::email('email', null, ['class' => 'form-control', 'required', 'placeholder' => __('messages.enter_email')])); ?>

    </div>

    
    
    
    
    
    
    
    
    
    
    
    

    <div class="col-md-6">
        <div class="form-group">
            <?php echo e(Form::label('dob', __('messages.dob').':')); ?>

            <?php echo e(Form::text('dob', !empty($user->dob) ? \Carbon\Carbon::parse($user->dob)->format('m/d/Y') : null, ['class' => 'form-control datepicker', 'placeholder' => __('messages.select_dob'), 'data-date-end-date'=>"0d", 'autocomplete'=>'off'])); ?>

        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <?php echo e(Form::label('experience', __('messages.experience').':')); ?><span><?php echo e(__('messages.in_year')); ?></span>
            <?php echo e(Form::text('experience',null , ['class' => 'form-control', 'step'=>'any', 'placeholder' => __('messages.enter_experience'),'min'=>0,'maxlength'=>'2', 'onkeyup'=>"if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')"])); ?>

        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <?php echo e(Form::label('job_title', __('messages.job_title').':')); ?><span class="text-danger">*</span>
            <?php echo e(Form::text('job_title', null, ['class' => 'form-control', 'required', 'placeholder' =>  __('messages.enter_job_title')])); ?>

        </div>
    </div>

    <div class="form-group col-md-6">
        <?php echo e(Form::label('country',__('messages.country').':')); ?><span class="text-danger">*</span>
        <?php echo e(Form::select('country_id', $countries, null, ['id'=>'countryId', 'class' => 'form-control', 'placeholder' => __('messages.select_country'), 'required'])); ?>

    </div>
    <div class="form-group col-md-6">
        <?php echo e(Form::label('state',__('messages.state').':')); ?><span class="text-danger">*</span>
        <?php echo e(Form::select('state_id', (isset($states) && $states != null ? $states : []), null, ['id'=>'stateId', 'class' => 'form-control', 'placeholder' => __('messages.select_state'), 'required'])); ?>

    </div>
    <div class="form-group col-md-6">
        <?php echo e(Form::label('city',__('messages.city').':')); ?><span class="text-danger">*</span>
        <?php echo e(Form::select('city_id', (isset($cities) && $cities != null ? $cities :[]), null, ['id'=>'cityId', 'class' => 'form-control', 'placeholder' => __('messages.select_city'),'required'])); ?>

    </div>
    <div class="form-group custom-control-alternative custom-checkbox ml-4 p-3">
        <input type="checkbox" id="remember" name="available_as_freelancer" value="1" class="custom-control-input"
               <?php if($user->available_as_freelancer == true): ?> checked <?php endif; ?>>
        <label class="custom-control-label" for="remember"><h4 class="font-weight-normal"><?php echo e(__('messages.available_as_freelancer')); ?></h4>
        </label>
    </div>

    <div class="col-md-12">
        <div class="form-group">
            <?php echo e(Form::label('about_me', __('messages.about_me').':')); ?><span class="text-danger">*</span>
            <?php echo e(Form::textarea('about_me', null, ['class' => 'form-control', 'cols'=>3, 'id'=>'userAboutMe', 'required', 'placeholder' => __('messages.about_me_text')])); ?>

        </div>
    </div>

    <div class="form-group col-sm-12 d-flex">
        <?php echo e(Form::button(__('messages.save'), ['type'=>'submit','class' => 'btn btn-primary','id'=>'btnProfileSave', 'data-loading-text'=>"<span class='spinner-border spinner-border-sm'></span> Processing..."])); ?>

        <a href="<?php echo e(route('users.edit',$user->id)); ?>" class="btn btn-light text-dark"><?php echo e(__('messages.cancel')); ?></a>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/users/edit_fields.blade.php ENDPATH**/ ?>