<div id="editProfileModal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-lg">
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e(__('messages.user.edit_profile')); ?></h5>
                <button type="button" aria-label="Close" class="close outline-none" data-dismiss="modal">×</button>
            </div>
            <?php echo e(Form::open(['id'=>'editProfileForm','files'=>true])); ?>

            <div class="modal-body">
                <div class="alert alert-danger d-none" id="validationErrorsBox"></div>
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="form-group col-sm-6">
                        <?php echo e(Form::label('first name', __('messages.first_name').':')); ?><span class="required text-red">*</span>
                        <?php echo e(Form::text('first_name', null, ['id'=>'pfName','class' => 'form-control firstName','required', 'autofocus', 'tabindex' => "1",'placeholder' => __('messages.first_name')])); ?>

                    </div>
                    <div class="form-group col-sm-6">
                        <?php echo e(Form::label('last name', __('messages.last_name').':')); ?><span class="required text-red">*</span>
                        <?php echo e(Form::text('last_name', null, ['id'=>'plName','class' => 'form-control','required', 'autofocus', 'tabindex' => "2",'placeholder' => __('messages.last_name')])); ?>

                    </div>
                    <div class="form-group col-sm-6">
                        <div class="row">
                            <div class="col-6 col-xl-5">
                                <?php echo e(Form::label('image', __('messages.profile').':')); ?>

                                <label class="image__file-upload text-white"> <?php echo e(__('messages.choose')); ?>

                                    <?php echo e(Form::file('photo',['id'=>'profileImage','class' => 'd-none','accept'=>'image/gif,image/png,image/jpg,image/jpeg'])); ?>

                                </label>
                            </div>
                            <div class="col-6 col-xl-6 pl-0 mt-1">
                                <img id='previewImage' class="img-thumbnail thumbnail-preview"
                                     src="">
                            </div>
                        </div>
                    </div>
                    <div class="form-group col-sm-6">
                        <?php echo e(Form::label('email', __('messages.email').':')); ?><span class="required text-red">*</span>
                        <?php echo e(Form::email('email', null, ['id'=>'pfEmail','class' => 'form-control','required', 'tabindex' => "3",'placeholder' => __('messages.enter_email')])); ?>

                    </div>
                </div>
                    <?php echo e(Form::button(__('messages.save'), ['type'=>'submit','class' => 'btn btn-primary','id'=>'btnPrEditSave','data-loading-text'=>"<span class='spinner-border spinner-border-sm'></span> Processing...", 'tabindex' => "4"])); ?>

                    <button type="button" class="btn text-dark btn-light ml-1 edit-cancel-margin margin-left-5"
                            data-dismiss="modal"><?php echo e(__('messages.cancel')); ?>

                    </button>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/profile/edit_profile.blade.php ENDPATH**/ ?>