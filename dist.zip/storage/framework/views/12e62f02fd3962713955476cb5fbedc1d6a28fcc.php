<div id="changeLanguageModal" class="modal fade" role="dialog" tabindex="-1">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content left-margin">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e(__('messages.language.change_language')); ?></h5>
                <button type="button" aria-label="Close" class="close" data-dismiss="modal">×</button>
            </div>
            <?php echo e(Form::open(['id'=>'changeLanguageForm'])); ?>

            <div class="modal-body">
                <div class="alert alert-danger d-none" id="editProfileValidationErrorsBox"></div>
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="form-group col-12">
                        <?php echo e(Form::label('language',__('messages.language.language').':')); ?><span
                                class="required text-danger">*</span>
                        <?php echo e(Form::select('language', \App\Models\User::LANGUAGES, Auth::user()->language, ['id'=>'language','class' => 'form-control','required'])); ?>

                    </div>
                </div>
                <div class="text-right d-flex align-items-center justify-content-end">
                    <?php echo e(Form::button(__('messages.save'), ['type'=>'submit','class' => 'btn btn-primary','id'=>'btnLanguageChange','data-loading-text'=>"<span class='spinner-border spinner-border-sm'></span> Processing..."])); ?>

                    <button type="button" class="btn btn-light text-dark left-margin" data-dismiss="modal"><?php echo e(__('messages.cancel')); ?>

                    </button>
                </div>
            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/profile/change_langauge.blade.php ENDPATH**/ ?>