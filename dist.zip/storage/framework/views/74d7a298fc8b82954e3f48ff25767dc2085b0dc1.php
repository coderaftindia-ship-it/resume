<?php $__env->startSection('title'); ?>
    <?php echo e(__('messages.edit_user')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/intel/css/intlTelInput.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/summernote.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="header bg-primary pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <h6 class="h2 text-white d-inline-block mb-0"><?php echo e(__('messages.profile')); ?></h6>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid mt--6">
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-6 edit-user-div">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="alert alert-danger d-none" id="validationErrorsBox"></div>

                        <?php echo $__env->make('users.user-profile-image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo e(Form::model($user,['route' => ['users.update',$user->id],'method'=>'put','id' =>'updateUserForm'])); ?>

                        <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                        <?php echo $__env->make('users.edit_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>
    let countryId = '<?php echo e($user->country_id); ?>';
    let stateId = '<?php echo e($user->state_id); ?>';
    let cityId = '<?php echo e($user->city_id); ?>';
    let isEdit = true;
    let phoneNo = "<?php echo e(old('region_code').old('phone')); ?>";
    let aboutMeText = "<?php echo e(__('messages.about_me_text')); ?>";
    let selectState = "<?php echo e(__('messages.select_state')); ?>";
    let selectCity = "<?php echo e(__('messages.select_city')); ?>";
    let regionCode = "<?php echo e($user->region_code); ?>";
</script>
<?php $__env->startSection('page_js'); ?>
    <script src="<?php echo e(mix('assets/js/custom/phone-number-code.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/summernote.min.js')); ?>"></script>
    <script src="<?php echo e(mix('assets/js/users/users.js')); ?>"></script>
    <script src="<?php echo e(mix('assets/js/custom/country-state-city.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/users/edit.blade.php ENDPATH**/ ?>