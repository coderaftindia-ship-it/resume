<!-- recent work section start -->
<section class="recent-work padding-top-100 padding-top-md-50 custom-padding-top-25" id="recent-work">
    <div class="first-content text-center">
        <h2 class="first-content__heading position-relative text-uppercase mb-5 custom_heading_tag custom-mb-1"
            data-aos="fade-up" data-aos-once="true">
            Recent Works
        </h2>
    </div>
    <div class="container">
        <div class="recent-work__block tab ">
            <nav class="nav nav-tabs">
                <?php $__empty_1 = true; $__currentLoopData = $recentWorksType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $recentWorkType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="#/" class="nav-item nav-link tablinks recent-work-field pb-3"
                       data-field="<?php echo e($recentWorkType->id); ?>">
                        <span class="<?php echo e($loop->first ? 'active':''); ?> recent-work-details"><?php echo e($recentWorkType->name); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h5>Recent work not available</h5>
                <?php endif; ?>
            </nav>

            <div class="recent-work-div-front">
                <section class="gallery">
                    <div class="container p-0">
                        <div class="grid">
                            <div class="tab-content">
                                <?php $__empty_1 = true; $__currentLoopData = $recentWorksType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentWorkType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div id="<?php echo e($recentWorkType->id); ?>" class="tabcontent p-0">
                                        <div class="row">
                                            <?php $__currentLoopData = $recentWorkType->recentWorks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $recentWork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($loop->iteration == 1 || $loop->iteration == 2 || $loop->iteration == 3): ?>
                                                    <div class="col-xs-4 col-md-4 pl-0 pr-0">
                                                        <?php elseif($loop->iteration == 4 || $loop->iteration == 5): ?>
                                                            <div class="col-xs-4 col-md-4 pl-0 pr-0">
                                                                <?php else: ?>
                                                                    <div class="col-xs-4 col-md-4 pl-0 pr-0">
                                                                        <?php endif; ?>
                                                                        
                                                                        <?php if(strpos($recentWork->link,'https://') !== false || strpos($recentWork->link,'http://') !== false || is_null($recentWork->link)): ?>
                                                                            <a class="text-center"
                                                                                    href="<?php echo e(isset($recentWork->link) ? $recentWork->link : 'javascript:void(0)'); ?>">
                                                                        <?php else: ?>
                                                                            <a class="text-center"
                                                                               href="//<?php echo e(isset($recentWork->link) ? $recentWork->link : 'javascript:void(0)'); ?>/">
                                                                        <?php endif; ?>
                                                                            <figure class="img-container mb-0">
                                                                                <img
                                                                                    data-src="<?php echo e($recentWork->attachment_url); ?>"
                                                                                    class="recent-work-img mb-0 lazy">
                                                                                <h3 class="img-title text-decoration-none text-dark text-wrap"><?php echo e($recentWork->title); ?></h3>
                                                                            </figure>
                                                                        </a>
                                                                    </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <h5>Recent work not available</h5>
                                                    <?php endif; ?>
                                        </div>
                                    </div>
                            </div>
                </section>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/web/sections/recent_work.blade.php ENDPATH**/ ?>