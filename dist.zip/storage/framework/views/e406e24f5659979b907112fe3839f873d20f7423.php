<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>