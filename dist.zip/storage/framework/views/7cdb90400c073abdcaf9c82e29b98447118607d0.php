<table class="table table-responsive table-striped table-bordered datatable-table" id="skillsTable">
    <thead>
    <tr>
        <th scope="col"><?php echo e(__('messages.name')); ?></th>
        <th scope="col"><?php echo e(__('messages.percentage')); ?></th>
        <th scope="col"><?php echo e(__('messages.action')); ?></th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/skills/table.blade.php ENDPATH**/ ?>