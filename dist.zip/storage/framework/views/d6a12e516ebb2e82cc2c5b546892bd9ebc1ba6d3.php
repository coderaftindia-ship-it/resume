<!-- exp edu section starts -->
<section class="experience-education padding-top-100 padding-top-md-50 custom-padding-top-15" id="education-profile">
    <div class="container">
        <div class="tabs-penal" data-aos="fade-up" data-aos-once="true">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item d-flex flex-row">
                    <a href="#uncontrolled-tab-example-tab-experience"
                       class="nav-item nav-link active custom_heading_tag custom-exp-border"
                       data-toggle="tab">Experience</a>
                    <a href="#uncontrolled-tab-example-tab-education" id="educationDetails"
                       class="nav-item nav-link custom_heading_tag custom-edu-border" data-toggle="tab">Education</a>
                </li>
            </ul>
            <div class="tab-content custom-mt-0" data-aos="fade-up" data-aos-once="true">
                <div id="uncontrolled-tab-example-tab-experience"
                     aria-labelledby="uncontrolled-tab-example-tab-experience" role="tabpanel"
                     class="fade tab-pane active show inner-content custom-m-top">
                    <div class="nav-tabs-content mt-5">
                        <div class="all-details position-relative">
                            <?php $__empty_1 = true; $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="all-details__block pb-md-5 pb-4 position-relative" data-aos="fade-up"
                                     data-aos-once="true">
                                    <span class="all-details__circle-button <?php if($loop->first): ?> active-details <?php endif; ?>"></span>
                                    <div class="row">
                                        <div class="col-md-8 col-12">
                                            <span
                                                class="all-details__position d-inline-block align-middle pr-3"><?php echo e($experience->job_title); ?></span>
                                            <span
                                                class="all-details__company-name d-inline-block align-middle">- <?php echo e($experience->company); ?></span>
                                            <strong
                                                class="d-block mt-md-1 mt-2 mb-md-0 mb-2"><?php echo e($experience->state->name); ?>

                                                , <?php echo e($experience->country->name); ?></strong>
                                        </div>
                                        <div class="col-md-4 col-12 text-md-right pl-md-0 d-flex d-md-block flex-wrap justify-content-between">
                                            <span class="all-details__old-time d-block mb-2 pr-md-0 pr-3">
                                                <?php echo e(formatStartAndEndDate($experience->start_date, !is_null($experience->end_date) ? $experience->end_date : \Carbon\Carbon::now())); ?>

                                            </span>
                                            <span class="all-details__currently-time d-block custom_currently_time">
                                                <?php if($experience->currently_work_here): ?>
                                                    <?php echo e($experience->start_date->format('F Y')); ?> - currently
                                                <?php else: ?>
                                                    <?php echo e($experience->start_date->format('F Y')); ?>  -  <?php echo e($experience->end_date ? $experience->end_date->format('F Y') : '-'); ?>

                                                <?php endif; ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h5>Experience not available</h5>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div id="uncontrolled-tab-example-tab-education"
                     aria-labelledby="uncontrolled-tab-example-tab-experience" role="tabpanel"
                     class="fade tab-pane active inner-content custom-m-top">
                    <div class="nav-tabs-content mt-5">
                        <div class="all-details position-relative education-block">
                            <?php $__empty_1 = true; $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="all-details__block pb-md-5 pb-4 position-relative">
                                    <span class="all-details__circle-button  <?php if($loop->first): ?> active-details <?php endif; ?>"></span>
                                    <div class="row">
                                        <div class="col-md-8 col-12">
                                            <span
                                                class="all-details__position d-inline-block align-middle pr-3"><?php echo e($education->qualification); ?></span>
                                            <span
                                                class="all-details__company-name d-inline-block align-middle">- <?php echo e($education->school_name); ?></span>
                                            <strong
                                                class="d-block mt-md-1 mt-2 mb-md-0 mb-2"><?php echo e($education->state->name); ?>

                                                , <?php echo e($education->country->name); ?></strong>
                                        </div>
                                        <div
                                            class="col-md-4 col-12 text-md-right pl-md-0 d-flex d-md-block flex-wrap justify-content-between">
                                            <span
                                                class="all-details__old-time d-block mb-2 pr-md-0 pr-3">
                                                <?php echo e(formatStartAndEndDate($education->start_date, !is_null($education->end_date) ? $education->end_date : \Carbon\Carbon::now())); ?>

                                            </span>
                                            <span class="all-details__currently-time d-block custom_currently_time"> 
                                                <?php if($education->currently_studying_here): ?>
                                                    <?php echo e($education->start_date->format('F Y')); ?> - currently
                                                <?php else: ?>
                                                    <?php echo e($education->start_date->format('F Y')); ?>  -  <?php echo e($education->end_date ? $education->end_date->format('F Y') : '-'); ?>

                                                <?php endif; ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h5>Education not available</h5>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/web/sections/education_profile.blade.php ENDPATH**/ ?>