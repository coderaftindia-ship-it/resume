<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white custom_sidenav"
     id="sidenav-main">
    <div class="scrollbar-inner">
        <div class="close_icon_container">
            <div class="close_icon">
                <i class="fas fa-times"></i>
            </div>
        </div>
        <div class="sidenav-header align-items-center h-auto">
            <div class="navbar-brand custom-sidebar-logo d-flex justify-content-center align-items-center flex-column"
                 href="javascript:void(0)">
                <a href="<?php echo e(route('front')); ?>" class="mb-2">
                    <img class="navbar-brand-img app-header-logo object-cover"
                         src="<?php echo e(asset(getAdminSettingValue('company_logo'))); ?>" width="65"
                         alt="Infyom Logo">
                </a>
                <a href="<?php echo e(url('/')); ?>"
                   class="text-dark font-weight-bold custom_disabled_span text-wrap width-150px"><?php echo e(html_entity_decode(getAdminSettingValue('company_name'))); ?></a>
            </div>
        </div>
        <div class="input-group px-3 custom_disabled_span">
            <input type="text" class="form-control searchTerm" id="searchText"
                   placeholder="<?php echo e(__('messages.search_menu')); ?>"
                   autocomplete="off">
            <div class="input-group-append">
                <div class="input-group-text menu-search-icon">
                    <i class="fas fa-search search-sign"></i>
                    <i class="fas fa-times close-sign"></i>
                </div>
            </div>
            <div class="no-results mt-3 ml-1"><?php echo e(__('No Matching records found')); ?></div>
        </div>
        <div class="navbar-inner">
            <div class="collapse navbar-collapse" id="sidenav-collapse-main">
                <ul class="navbar-nav">
                    
                    
                    
                    
                    
                    
                    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>