<!-- Fonts -->

<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>"  type="text/css"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">

<!-- slick slider css  -->
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/slick.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/slick-theme.css')); ?>"/>

<link rel="stylesheet" href="<?php echo e(asset('assets/css/sweetalert2.css')); ?>"  type="text/css"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/iziToast.min.css')); ?>">

<!-- style  -->
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/header.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/home.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/fonts.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/variable.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/blog.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/blog-detail.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/mixin.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/scrollbar.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/dark-theme.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/web/css/layout.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('css/layout.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/web/style.css')); ?>">


<!-- aos animation  -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/aos.css')); ?>">
<link href="<?php echo e(asset('assets/css/phone-number-code.css')); ?>" rel="stylesheet" type="text/css" />
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/web/css.blade.php ENDPATH**/ ?>