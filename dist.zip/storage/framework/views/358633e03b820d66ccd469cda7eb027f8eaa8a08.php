<p class="copyright__content mb-0">
    All rights reserved  &copy; <?php echo e(date('Y')); ?>

    <a class="text-decoration-none pl-1" href="<?php echo e(getWebsiteUrl()); ?>" target="_blank"><?php echo e(getAppName()); ?></a>
</p>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/web/footer.blade.php ENDPATH**/ ?>