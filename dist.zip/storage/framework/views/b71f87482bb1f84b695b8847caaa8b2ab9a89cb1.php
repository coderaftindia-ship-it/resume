<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('users*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('users.edit',Auth::id())); ?>">
        <i class="fas fa-user big_size_icon  <?php echo e(checkRequest('users*')?'text-white':'text-orange'); ?>"></i>
        <span class="nav-link-text custom_disabled_span "><?php echo e(__('messages.profile')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('experiences*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('experiences.index')); ?>">
        <i class="fas fa-star big_size_icon  <?php echo e(checkRequest('experiences*')?'text-white':'text-info'); ?>"></i>
        <span class="nav-link-text custom_disabled_span "><?php echo e(__('messages.experiences')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('educations*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('educations.index')); ?>">
        <i class="fas fa-graduation-cap big_size_icon  <?php echo e(checkRequest('educations*')?'text-white':'text-yellow'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.education')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('skills*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('skills.index')); ?>">
        <i class="fas fa-clipboard-list big_size_icon  <?php echo e(checkRequest('skills*')?'text-white':'text-dark'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.skills')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('testimonials*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('testimonials.index')); ?>">
        <i class="fas fa-sticky-note big_size_icon  <?php echo e(checkRequest('testimonials*')?'text-white':'text-purple'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.testimonials')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus">
    <a class="nav-link" href="#pricingPlan" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-hand-holding-usd big_size_icon big_size_icon custom-price-plan-icon-color"></i>
        <span class="custom_disabled_span"><?php echo e(__('messages.pricing_plans')); ?></span>
    </a>
    <ul class="collapse side-menus list-unstyled sidebar-dropdown" id="pricingPlan">
        <ul class="nav">
            <li class="nav-item side-menus nav-item-width <?php echo e(Request::is('pricing-plans*')?'active':''); ?>">
                <a class="nav-link custom_pl" href="<?php echo e(route('pricing-plans.index')); ?>">
                    <i class="fas fa-hands <?php echo e(checkRequest('pricing-plans*')?'text-white':'text-pink'); ?> "></i>
                    <span class="nav-link-text"> <?php echo e(__('messages.pricing_plan_currency.plans')); ?></span>
                </a>
            </li>
            <li class="nav-item side-menus nav-item-width <?php echo e(Request::is('plan-currencies*')?'active':''); ?>">
                <a class="nav-link custom_pl" href="<?php echo e(route('plan-currencies.index')); ?>">
                    <i class="fas fa-money-bill-wave <?php echo e(checkRequest('plan-currencies*')?'text-white':'text-currency-color'); ?> "></i>
                    <span class="nav-link-text"> <?php echo e(__('messages.pricing_plan_currency.plan_currencies')); ?></span>
                </a>
            </li>
        </ul>
    </ul>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus">
    <a class="nav-link" href="#recentWork" data-toggle="collapse" aria-expanded="false">
        <i class="fas fa-layer-group text-indigo big_size_icon "></i>
        <span class="custom_disabled_span"><?php echo e(__('messages.recent_works')); ?></span>
    </a>
    <ul class="collapse side-menus list-unstyled sidebar-dropdown" id="recentWork">
        <ul class="nav">
            <li class="nav-item side-menus nav-item-width <?php echo e(Request::is('recent-work-types*')?'active':''); ?>">
                <a class="nav-link custom_pl" href="<?php echo e(route('recent-work-types.index')); ?>">
                    <i class="fas fa-briefcase <?php echo e(checkRequest('recent-work-types*')?'text-white':'text-orange'); ?> sidebar-menu-category-color"
                       aria-hidden="true"></i> <span><?php echo e(__('messages.work_types')); ?></span>
                </a>
            </li>
            <li class="nav-item side-menus nav-item-width <?php echo e(Request::is('recent-works*')?'active':''); ?>">
                <a class="nav-link custom_pl" href="<?php echo e(route('recent-works.index')); ?>">
                    <i class="fab fa-weebly <?php echo e(checkRequest('recent-works*')?'text-white':'text-muted'); ?> side bar-menu-blog-color"
                       aria-hidden="true"></i><span><?php echo e(__('messages.works')); ?></span>
                </a>
            </li>
        </ul>
    </ul>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('services*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('services.index')); ?>">
        <i class="fas fa-wrench big_size_icon  <?php echo e(checkRequest('services*')?'text-white':'text-green'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.services')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('achievement*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('achievements.index')); ?>">
        <i class="fas fa-trophy big_size_icon   <?php echo e(checkRequest('achievement*')?'text-white':'text-dark-brown'); ?>"></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.achievements')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('enquiries*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('enquiries.index')); ?>">
        <i class="fas fas fa-question-circle big_size_icon  <?php echo e(checkRequest('enquiries*')?'text-white':''); ?>"></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.enquires')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('hire-me*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('hire-me.index')); ?>">
        <i class="fab fa-hire-a-helper big_size_icon  <?php echo e(checkRequest('hire-me*')?'text-white':'text-dark-green'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.hire_requests')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus">
    <a class="nav-link" href="#blogCategories" data-toggle="collapse" aria-expanded="false">
        <i class="fab fa-blogger-b text-default big_size_icon "></i>
        <span class="custom_disabled_span"><?php echo e(__('messages.blog')); ?></span>
    </a>
    <ul class="collapse side-menus list-unstyled sidebar-dropdown" id="blogCategories">
        <ul class="nav">
            <li class="nav-item side-menus nav-item-width <?php echo e(Request::is('categories*')?'active':''); ?>">
                <a class="nav-link custom_pl" href="<?php echo e(route('categories.index')); ?>">
                    <i class="far fa-list-alt <?php echo e(checkRequest('categories*')?'text-white':'sidebar-menu-category-color'); ?> "
                       aria-hidden="true"></i> <span> <?php echo e(__('messages.categories')); ?></span>
                </a>
            </li>
            <li class="nav-item side-menus nav-item-width <?php echo e(Request::is('blogs*')?'active':''); ?>">
                <a class="nav-link custom_pl" href="<?php echo e(route('blogs.index')); ?>">
                    <i class="fas fa-blog <?php echo e(checkRequest('blogs*')?'text-white':'side bar-menu-blog-color'); ?> "
                       aria-hidden="true"></i> <span><?php echo e(__('messages.blogs_category.posts')); ?></span>
                </a>
            </li>
        </ul>
    </ul>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('settings*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('settings.index')); ?>">
        <i class="fas fa-cog big_size_icon  <?php echo e(checkRequest('settings*')?'text-white':'sidebar-menu-setting-color'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.settings')); ?></span>
    </a>
</li>
<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasRole('super_admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('admin/dashboard*') ? 'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
        <i class="fas fa-tachometer-alt big_size_icon  <?php echo e(checkRequest('admin/dashboard*')?'text-white':'text-success'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.dashboard.dashboard')); ?></span>
    </a>
</li>
<li class="nav-item side-menus <?php echo e(Request::is('admin/users*') || Request::is('admin/user*') ? 'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('users.index')); ?>">
        <i class="fas fa-users big_size_icon  <?php echo e(checkRequest('admin/users*')?'text-white':'text-dark'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.admin_users.users')); ?></span>
    </a>
</li>
<li class="nav-item side-menus <?php echo e(Request::is('admin/countries*') ? 'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('countries.index')); ?>">
        <i class="fas fa-globe-americas big_size_icon  <?php echo e(checkRequest('admin/countries*')?'text-white':'text-info'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.countries.countries')); ?></span>
    </a>
</li>
<li class="nav-item side-menus <?php echo e(Request::is('admin/states*') ? 'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('states.index')); ?>">
        <i class="fas fa-flag big_size_icon  <?php echo e(checkRequest('admin/states*')?'text-white':'state-text-color'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.states.states')); ?></span>
    </a>
</li>
<li class="nav-item side-menus <?php echo e(Request::is('admin/cities*') ? 'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('cities.index')); ?>">
        <i class="fas fa-city big_size_icon  <?php echo e(checkRequest('admin/cities*')?'text-white':'city-text-color'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.cities.cities')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('super_admin')): ?>
<li class="nav-item side-menus">
    <a class="nav-link" href="#frontCMS" data-toggle="collapse" aria-expanded="false">
        <i class="fab fa-foursquare text-default big_size_icon "></i>
        <span class="custom_disabled_span"><?php echo e(__('messages.front_cms')); ?></span>
    </a>
    <ul class="collapse side-menus list-unstyled sidebar-dropdown" id="frontCMS">
        <ul class="nav">
            <li class="nav-item side-menus nav-item-width <?php echo e(Request::is('admin/section-one*')?'active':''); ?>">
                <a class="nav-link custom_pl" href="<?php echo e(route('cms.section.one.index')); ?>">
                    <i class="fab fa-stripe-s <?php echo e(checkRequest('admin/section-one*')?'text-white':'sidebar-menu-category-color'); ?> "
                       aria-hidden="true"></i> <span> <?php echo e(__('messages.front_side_cms.section_one')); ?></span>
                </a>
            </li>
            <li class="nav-item side-menus nav-item-width <?php echo e(Request::is('admin/section-two*')?'active':''); ?>">
                <a class="nav-link custom_pl" href="<?php echo e(route('cms.section.two.index')); ?>">
                    <i class="fab fa-stripe-s <?php echo e(checkRequest('admin/section-two*')?'text-white':'sidebar-menu-category-color'); ?> "
                       aria-hidden="true"></i> <span> <?php echo e(__('messages.front_side_cms.section_two')); ?></span>
                </a>
            </li>
        </ul>
    </ul>
</li>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('super_admin')): ?>
<li class="nav-item side-menus <?php echo e(Request::is('admin/settings*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.settings.index')); ?>">
        <i class="fas fa-cog big_size_icon  <?php echo e(checkRequest('admin/settings*')?'text-white':'sidebar-menu-setting-color'); ?> "></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.settings')); ?></span>
    </a>
</li>
<li class="nav-item side-menus <?php echo e(Request::is('admin/enquiries*')?'active':''); ?>">
    <a class="nav-link" href="<?php echo e(route('admin.enquiries.index')); ?>">
        <i class="fas fas fa-question-circle big_size_icon  <?php echo e(checkRequest('admin/enquiries*')?'text-white':''); ?>"></i>
        <span class="nav-link-text custom_disabled_span"><?php echo e(__('messages.enquires')); ?></span>
    </a>
</li>
<?php endif; ?>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/menu.blade.php ENDPATH**/ ?>