<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="To manage the InfyOm Portfolio">
    <meta name="author" content="InfyOm Technologies">

    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?> </title>
    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset(getAdminSettingValue('favicon'))); ?>" type="image/png">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Fonts -->
    <link href="//fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">

    <!-- Icons -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/nucleo/css/nucleo.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>">
    <link href="<?php echo e(asset('assets/css/sweetalert2.css')); ?>" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/iziToast.min.css')); ?>">
    <link href="<?php echo e(asset('assets/css/select2.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datetimepicker.min.css')); ?>">

    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('css/argon.css')); ?>" type="text/css">

    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

    <link href="<?php echo e(asset('assets/css/phone-number-code.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- CSS Libraries -->
    <?php echo $__env->yieldContent('page_css'); ?>
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
    <!-- Template CSS -->
</head>
<body id="app">
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('sidebar_js'); ?>

<div class="main-content" id="panel">

    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <footer>
        <div class="container-fluid padding-0">
            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </footer>
</div>

<?php echo $__env->make('profile.change_password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('profile.edit_profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('profile.change_langauge', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Scripts -->
<script src="<?php echo e(asset('vendor/js-cookie/js.cookie.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(mix('assets/js/sidebar_menu_search/sidebar_menu_search.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.nicescroll.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap-datepicker.js')); ?>"></script>

<script src="<?php echo e(asset('js/argon.js')); ?>"></script>
<?php echo $__env->yieldContent('page_js'); ?>
<?php echo $__env->yieldContent('scripts'); ?>
<script src="<?php echo e(mix('assets/js/app/app.js')); ?>"></script>
<script>
    let pdfDocumentImageUrl = "<?php echo e(asset('assets/img/pdf_icon.png')); ?>";
    let docxDocumentImageUrl = "<?php echo e(asset('assets/img/doc_icon.png')); ?>";
    let xlsxDocumentImageUrl = "<?php echo e(asset('assets/img/xlsx_icon.png')); ?>";
    let defaultImage = "<?php echo e(asset('img/infyom-logo.png')); ?>";
    let successMessage = "<?php echo e(session('successMessage')); ?>";
</script>
<script src="<?php echo e(mix('assets/js/custom/custom.js')); ?>"></script>
<script src="<?php echo e(mix('assets/js/user-profile/user-profile.js')); ?>"></script>
</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/app.blade.php ENDPATH**/ ?>