<!-- pricing plan section starts -->
<?php if($pricingPlans->count() > 0): ?>
    <section class="pricing-plans padding-top-100 padding-top-md-50" id="pricing-plan">
        <div class="first-content text-center">
            <h2 class="first-content__heading position-relative text-uppercase mb-5 custom_heading_tag custom-mb-2"
                data-aos="fade-up"
                data-aos-once="true">
                Pricing Plans
            </h2>
        </div>
        <div class="container" data-aos="fade-right" data-aos-duration="1500" data-aos-once="true">
            <div class="pricing-plans__block mt-2 d-inline-block w-100">
                <div class="row justify-content-center">
                    <?php $__empty_1 = true; $__currentLoopData = $pricingPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pricingPlan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-4 col-md-6 main-card fadeInLeft front-animation">
                            <?php
                            $inStyle = 'style';
                            $style = 'border-top: 7px solid';
                            ?>
                            <div class="card text-center position-relative h-100" <?php echo e($inStyle); ?>=
                            "<?php echo e($style); ?> <?php echo e(($pricingPlan->color == '#FFFFFF') ? '#f5365c' : $pricingPlan->color); ?>;">
                            <img
                                    src="<?php echo e($pricingPlan->icon_image); ?>"
                                    data-alt="plan-icon"
                                    class="mb-3 card-img-top lazy"
                                    width="70px"
                                    height="72px"
                            />
                            <div class="card-body">
                                <strong class="card-title text-uppercase d-block custom-space"><?php echo e(\App\Models\PricingPlan::PRICING_PLAN_TYPE[$pricingPlan->type]); ?></strong>
                            </div>
                            <ul class="list-group-flush ml-0 mb-2 h-100">
                                <?php $__currentLoopData = $pricingPlan->planAttributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planAttribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item mb-0 px-0">
                                        <i class="<?php echo e($planAttribute->attribute_icon); ?> pr-1"></i>
                                        <?php echo e($planAttribute->attribute_name); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <div class="mb-0 px-0 main-card__price-div">
                                <sup class="main-card__price-symbol"><?php echo e(!empty($pricingPlan->currency->currency_icon) ? $pricingPlan->currency->currency_icon : '$'); ?></sup>
                                <span class="main-card__price"><?php echo e($pricingPlan->price); ?></span>
                                <span>Per/<?php echo e(\App\Models\PricingPlan::PLAN_TYPE[$pricingPlan->plan_type]); ?></span>
                            </div>
                            <div class="card-footer bg-white px-0 pb-0 mt-0 border-0">
                                <a href="javascript:void(0)" class="btn btn-primary custom-btn mb-4 mt-3"
                                   id="createModel">
                                    Hire Me
                                </a>
                            </div>
                        </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h5>Pricing plan not available</h5>
                <?php endif; ?>
            </div>
        </div>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/web/sections/pricing_plan.blade.php ENDPATH**/ ?>