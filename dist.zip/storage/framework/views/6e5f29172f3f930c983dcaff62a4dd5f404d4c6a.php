<footer id="footer" class="border-0 frt-footer-bg">
    <div class="container">
        <div class="footer-widgets-wrap pb-3 m-0">
            <div class="row justify-content-between">
                <div class="col-md-4">
                    <div class="widget">
                        <h3 class="h1 mb-5">Got a Project?<br>Let's Talk!</h3>
                        <span class="text-black-50">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nobis quisquam aspernatur vero voluptas.</span>
                        <a href="mailto:noreply@canvas.com"
                           class="h4 text-dark mt-5 mb-4 d-block"><u>noreply@canvas.com</u> <i
                                    class="icon-line-arrow-right position-relative ms-2" style="top: 3px"></i></a>
                        <div>
                            <a href="http://facebook.com/semicolonweb"
                               class="social-icon si-small si-colored si-facebook" target="_blank">
                                <i class="icon-facebook"></i>
                                <i class="icon-facebook"></i>
                            </a>
                            <a href="http://instagram.com/semicolonweb"
                               class="social-icon si-small si-colored si-instagram" target="_blank">
                                <i class="icon-instagram"></i>
                                <i class="icon-instagram"></i>
                            </a>
                            <a href="http://youtube.com/semicolonweb" class="social-icon si-small si-colored si-youtube"
                               target="_blank">
                                <i class="icon-youtube"></i>
                                <i class="icon-youtube"></i>
                            </a>
                            <a href="#" class="social-icon si-small si-colored si-flattr">
                                <i class="icon-flattr"></i>
                                <i class="icon-flattr"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-md-5">
                    <h3 class="h1 mb-5">Want to Reach Us?</h3>
                    <form class="row mb-0" id="sendEnquiryForm">
                        <?php echo csrf_field(); ?>
                        <div class="col-6 form-group mb-4">
                            <input type="text" name="first_name" id="firstName" class="form-control border-form-control"
                                   placeholder="First Name" value="" required/>
                        </div>
                        <div class="col-6 form-group mb-4">
                            <input type="text" name="last_name" id="lastName" class="form-control border-form-control"
                                   placeholder="Last Name" value="" required/>
                        </div>
                        <div class="col-6 form-group mb-4">
                            <input type="email" name="email" id="email" class="form-control border-form-control"
                                   placeholder="Email Address" value="" required/>
                        </div>
                        <div class="col-6 form-group mb-4">
                            <span class="d-flex">
                                <h4 class="font-weight-light d-flex align-items-center my-0">+</h4>
                                <input type="text" name="region_code"
                                       class="form-control border-form-control w-25 text-center"
                                       value="91" id="regionCode" maxlength="3"
                                       onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')"
                                       required/>
                                <input type="text" name="phone" id="phone" class="form-control border-form-control"
                                       placeholder="Phone"
                                       value="" maxlength="10"
                                       onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')"
                                       required/>
                            </span>
                        </div>
                        <div class="col-12 form-group mb-4">
                            <textarea id="message" class="form-control border-form-control contact-textarea-size"
                                      placeholder="Message" name="message" cols="10" rows="20" required></textarea>
                        </div>
                        <div class="col-12 custom-captcha">
                            <?php echo NoCaptcha::renderJs(); ?>

                            <?php echo NoCaptcha::display(); ?>

                        </div>
                        <div class="col-12 mt-3">
                            <button type="submit" name="landing-enquiry-submit"
                                    class="button h-translatey-3 bg-dark rounded-pill btnAction">
                                <i class="icon-line-loader icon-spin m-0 d-none"></i>
                                Send
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row py-5 footer-section">
            <div class="col-lg-6 col-md-12 col-sm-12 col-12 d-flex">
                All rights reserved &copy; <?php echo e(date('Y')); ?> &nbsp;
                <a class="text-decoration-none text-primary" href="<?php echo e(getAdminSettingValue('website')); ?>" target="_blank">
                    <?php echo e(getAdminSettingValue('company_name')); ?>

                </a>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-12 d-flex justify-content-end">
                <a class="text-decoration-none text-primary" href="<?php echo e(route('terms.conditions')); ?>">
                    <?php echo e(__('messages.terms_conditions')); ?>

                </a>
                &nbsp;&nbsp;&nbsp;
                <a class="text-decoration-none text-primary" href="<?php echo e(route('privacy.policy')); ?>">
                    <?php echo e(__('messages.privacy_policy')); ?>

                </a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/front/footer.blade.php ENDPATH**/ ?>