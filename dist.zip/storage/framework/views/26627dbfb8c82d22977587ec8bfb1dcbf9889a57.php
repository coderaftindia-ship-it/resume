<!-- Footer -->
<footer class="footer">
    <div class="row align-items-center justify-content-lg-between">
        <div class="col-md-12">
            <div class="copyright text-center  text-lg-left  text-muted">
                <?php echo e(__('messages.all_rights_reserved')); ?> &copy; <?php echo e(date('Y')); ?> <a
                        href="<?php echo e(getAdminSettingValue('website')); ?>" class="font-weight-bold ml-1 footer-link-color"
                        target="_blank"><?php echo e(getAdminSettingValue('company_name')); ?></a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/footer.blade.php ENDPATH**/ ?>