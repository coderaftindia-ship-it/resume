<div name="home">
    <section class="profile-information padding-top-100 padding-top-md-50 text-center" id="profile">
        <img data-src="<?php echo e(asset('assets/img/ptofile-bg-2.png')); ?>"  data-value="-5" class="profile-bg-img lazy">
        <div class="container">
            <div data-aos="fade-up" data-aos-duration="800" data-aos-once="true">
                <div>
                    <div class="profile-information__first-image position-relative">
                        <div class="position-relative">
                            <img data-src="<?php echo e(isset($user->media[0])?$user->profile_image:asset('img/infyom-logo.png')); ?> "
                                 alt="award-icon"
                                 class="img-fluid mb-3 lazy" width="198px"
                                 height="198px"/>
                        </div>
                    </div>
                    <div class="profile-information__content bg-white">
                        <div class="details text-center">
                            <h1 class="details__name mb-3 custom_profile_heading"><?php echo e($user->full_name); ?></h1>
                            <span class="details__designation mb-3"><?php echo e($user->job_title); ?></span>
                            <div class="nav mt-4 row">
                                <div class="col-xl-12 col-lg-6">
                                    <div class="row">
                                        <div class="col-xl-5 col-12">
                                            <div class="social-info text-left">
                                                <a class="text-decoration-none position-relative" href="tel:<?php echo e($user->phone); ?>">
                                                    <i class="fas fa-phone-alt mr-2 custom_phone"></i><?php echo e('+'.$user->region_code.' '.$user->phone); ?>

                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-12 pl-xl-0">
                                            <div class="social-info text-left">
                                                <a class="text-decoration-none position-relative" href="/#">
                                                    <i class="fas fa-map-marker-alt mr-2 custom_city"></i><?php echo e($user->city->name.', '.$user->country->name); ?>

                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-12 pl-xl-0">
                                            <div class="social-info text-left">
                                                <a class="text-decoration-none position-relative" href="/#">
                                                    <i class="fas fa-calendar-check mr-2 custom_dob"></i><?php echo e(\Carbon\Carbon::parse($user->dob)->age); ?>

                                                    Year Old
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-6">
                                    <div class="row">
                                        <div class="col-xl-5 col-12">
                                            <div class="social-info text-left">
                                                <a class="text-decoration-none position-relative" href="mailto:<?php echo e($user->email); ?>">
                                                    <i class="fas fa-envelope mr-2 custom_email"></i><?php echo e($user->email); ?>

                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-xl-4 col-12 pl-xl-0">
                                            <div class="social-info text-left">
                                                <a class="text-decoration-none position-relative"
                                                   href="/#">
                                                    <i class="fas fa-briefcase mr-2 custom_exp"></i><?php echo e($user->experience); ?>

                                                    Year Experience
                                                </a>
                                            </div>
                                        </div>
                                        <?php if($user->available_as_freelancer): ?>
                                            <div class="col-xl-3 col-12 pl-xl-0">
                                                <div class="social-info text-left">
                                                    <a class="text-decoration-none position-relative" href="#/">
                                                        <i class="fas fa-check-square mr-2 custom_freelancer"></i>
                                                        Available Freelancer
                                                    </a>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <a href="javascript:void(0)" class="btn btn-primary custom-btn mb-4 mt-3" id="createModel">
                                Hire Me
                            </a>
                            <ul class="nav justify-content-center align-items-center ml-0 social-link">
                                <?php if(count($socialSettings) > 0): ?>
                                    <?php $__currentLoopData = $socialSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="nav-item mb-0">
                                            <?php if(strpos($socialSetting->value,'https://') !== false || strpos($socialSetting->value,'http://') !== false || is_null($socialSetting->value)): ?>
                                                <a class="nav-link" href="<?php echo e($socialSetting->value); ?>" target="_blank">
                                                    <i class="<?php echo e($socialSetting->key); ?>"></i>
                                                </a>
                                            <?php else: ?>
                                                <a class="nav-link" href="//<?php echo e($socialSetting->value); ?>" target="_blank">
                                                    <i class="<?php echo e($socialSetting->key); ?>"></i>
                                                </a>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/web/sections/profile.blade.php ENDPATH**/ ?>