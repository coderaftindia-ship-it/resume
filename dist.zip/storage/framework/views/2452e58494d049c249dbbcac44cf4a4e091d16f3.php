<nav class="navbar navbar-top navbar-expand navbar-dark bg-primary border-bottom">
    <div class="container-fluid">
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto d-xl-none">
                <li class="nav-item">
                    <!-- Sidenav toggler -->
                    <div class="pr-3 admin_menu_icon" data-action="sidenav-pin"
                         data-target="#sidenav-main">
                        <div class="toggle_line">
                            <i class="sidenav-toggler-line"></i>
                            <i class="sidenav-toggler-line"></i>
                            <i class="sidenav-toggler-line"></i>
                        </div>
                    </div>
                </li>
            </ul>
            <ul class="navbar-nav mr-auto d-xl-block d-none">
                <li class="nav-item">
                    
                    <div class="pr-3 desktop_admin_menu_icon">
                        <div class="toggle_line">
                            <i class="sidenav-toggler-line"></i>
                            <i class="sidenav-toggler-line"></i>
                            <i class="sidenav-toggler-line"></i>
                        </div>
                    </div>
                </li>
            </ul>
            <?php if(session('impersonated_by')): ?>
                <a href="<?php echo e(route('impersonate.leave')); ?>"
                   class="mr-3 text-danger" data-toggle="tooltip"
                   title="<?php echo e(__('messages.admin_users.return_to_admin')); ?>">
                    <i class="fas fa-user-check font-size-25px"></i>
                </a>
            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
            <a href="<?php echo e(url('p'.DIRECTORY_SEPARATOR.getLoggedInUser()->user_name)); ?>"
               class="mr-3 text-danger" target="_blank" data-toggle="tooltip"
               title="<?php echo e(__('messages.user.preview_blog')); ?>">
                <i class="fas fa-eye font-size-25px"></i>
            </a>
            <?php endif; ?>
            <ul class="navbar-nav align-items-center  ml-auto ml-md-0 ">
                <li class="dropdown language-menu no-hover mr-2">
                    <a href="<?php echo e(getLoggedInUser()->hasRole('super_admin') ? route('admin.settings.index') : route('settings.index')); ?>"
                       data-toggle="tooltip" title="<?php echo e(__('messages.settings')); ?>">
                        <i class="fa fa-cog text-primary font-size-25px"></i>
                    </a>
                </li>
                
                
                
                
                
                
                
                
                
                


                
                
                <li class="nav-item dropdown">
                    <a class="nav-link pr-0" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                       aria-expanded="false">
                        <div class="media align-items-center">
                  <span class="avatar avatar-sm rounded-circle">
                    <img alt="Image placeholder" src="<?php echo e(Auth::user()->profile_image); ?>" class="bg-white">
                  </span>
                            <div class="media-body  ml-2  d-none d-lg-block">
                                <span class="mb-0 text-sm text-dark font-weight-bold"><?php echo e(__('messages.user.hi')); ?>,&nbsp;&nbsp;<?php echo e(Auth::user()->full_name); ?></span>
                            </div>
                        </div>
                    </a>
                    <div class="dropdown-menu  dropdown-menu-right ">
                        <div class="dropdown-header noti-title">
                            <h6 class="text-overflow m-0"><?php echo e(__('messages.user.welcome')); ?>,&nbsp;&nbsp;<?php echo e(Auth::user()->full_name); ?></h6>
                        </div>
                        <a href="#!" class="dropdown-item edit-profile" data-target="#editProfileModal"
                           data-toggle="modal" data-id="<?php echo e(auth()->id()); ?>">
                            <i class="ni ni-single-02"></i>
                            <span><?php echo e(__('messages.user.edit_profile')); ?></span>
                        </a>
                        <a href="#!" class="dropdown-item" data-toggle="modal" data-target="#changePasswordModal"
                           data-id="<?php echo e(auth()->id()); ?>">
                            <i class="ni ni-lock-circle-open"></i>
                            <span><?php echo e(__('messages.user.change_password')); ?></span>
                        </a>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-id="<?php echo e(auth()->id()); ?>"
                           data-target="#changeLanguageModal"><i
                                    class="fa fa-language"></i><?php echo e(__('messages.user.change_language')); ?></a>
                        <?php if(session('impersonated_by')): ?>
                            <a class="dropdown-item" href="<?php echo e(route('impersonate.leave')); ?>">
                                <i class="fas fa-user-check"></i><?php echo e(__('messages.admin_users.return_to_admin')); ?></a>
                        <?php endif; ?>
                        <div class="dropdown-divider"></div>
                        <a href="<?php echo e(url('logout')); ?>" class="dropdown-item"
                           onclick="event.preventDefault(); localStorage.clear();  document.getElementById('logout-form').submit();">
                            <i class="ni ni-button-power"></i>
                            <span><?php echo e(__('messages.user.logout')); ?></span>
                        </a>
                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" class="d-none">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/header.blade.php ENDPATH**/ ?>