<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="To manage the InfyOm Portfolio">
    <meta name="author" content="InfyOm Technologies">

    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?> </title>
    <!-- Favicon -->
    
    

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Fonts -->
    <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/nucleo/css/nucleo.css')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/@fortawesome/fontawesome-free/css/all.min.css')); ?>" type="text/css">

    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('css/argon.css?v=1.2.0')); ?>" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/login.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/iziToast.min.css')); ?>">
    <!-- CSS Libraries -->

<?php echo $__env->yieldPushContent('css'); ?>
<!-- Template CSS -->
</head>
<body id="app">
<!-- Main content -->
<div class="main-content">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<!-- Footer -->
<footer class="py-3 position-relative login-footer" id="footer-main">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-xl-6">
                <div class="copyright text-center text-muted">
                    
                    
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Scripts -->
<script src="<?php echo e(asset('vendor/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js-cookie/js.cookie.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery.scrollbar/jquery.scrollbar.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery-scroll-lock/dist/jquery-scrollLock.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/argon.js?v=1.2.0')); ?>"></script>
<script src="<?php echo e(asset('assets/js/iziToast.min.js')); ?>"></script>

<?php echo $__env->yieldContent('page_js'); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/auth.blade.php ENDPATH**/ ?>