<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="skillModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="skillModalLabel"><?php echo e(__('messages.edit_skill')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="alert-danger alert d-none" id="editValidationErrorsBox"></div>
                <?php echo e(Form::open(['id' =>'skillUpdateForm','method'=>'post'])); ?>

                <?php echo e(Form::hidden('id',null,['id' => 'skillId'])); ?>

                <div class="form-group">
                    <?php echo e(Form::label('name', __('messages.name').':')); ?><span class="text-danger">*</span>
                    <i class="fas fa-question-circle ml-1 mt-1 general-question-mark" data-toggle="tooltip"
                       data-placement="top" title="<?php echo e(__('messages.skill_name_tooltip')); ?>"></i>
                    <?php echo e(Form::text('name', null , ['class' => 'form-control','id' => 'editName','placeholder' => __('messages.skill_placeholder.enter_skill_name'),'required'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('percentage', __('messages.percentage').':')); ?><span class="text-danger">*</span>
                    <?php echo e(Form::number('percentage', null , ['class' => 'form-control','id' => 'editPercentage','placeholder' => __('messages.skill_placeholder.enter_percentage'), 'min' => 1, 'max' => 100,'required', 'onkeyup' => 'if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,"")'])); ?>

                </div>
                <div class="d-flex align-items-center">
                    <?php echo e(Form::button(__('messages.save'), ['type' => 'submit', 'class' => 'btn btn-primary', 'id' => 'skillSaveBtn', 'data-loading-text' => "<span class='spinner-border spinner-border-sm'></span> Processing..."])); ?>

                    <?php echo e(Form::button(__('messages.cancel'), ['type' => 'button', 'class' => 'btn btn-light text-dark','data-dismiss'=>'modal'])); ?>

                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>
</div>


<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/skills/edit_model.blade.php ENDPATH**/ ?>