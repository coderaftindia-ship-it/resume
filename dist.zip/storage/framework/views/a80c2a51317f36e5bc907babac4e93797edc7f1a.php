<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta name="description" content="To manage the InfyOm Portfolio">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?> </title>
    <link rel="icon" href="<?php echo e(asset(getSettingValue('favicon'))); ?>" type="image/png">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php echo $__env->make('layouts.web.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('page_css'); ?>
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
</head>
<body>
<?php if(!Request::is('blog*') && !Request::is('search-blog*')): ?>
    <header class="d-lg-flex align-items-center justify-content-lg-center justify-content-end">
        <?php echo $__env->make('layouts.web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>
    <!-- main part starts -->
    <main class="main-page">
        <a id="top_button" class="d-flex justify-content-center align-items-center"><i
                class="fas fa-arrow-up text-white"></i> </a>
        <div id="wrapper">
            <div id="circle_id" class="circle icon">
                <span class="line top"></span>
                <span class="line middle"></span>
                <span class="line bottom"></span>
            </div>
        </div>
        <div class="fixed-plugin">
            <div class="click_show">
                <a href="#/" data-toggle="dropdown" aria-expanded="true">
                    <i class="fa fa-cog"></i>
                </a>
                <ul class="dropdown-menu show">
                    <li class="adjustments-line text-center">
                            <i class="fas fa-toggle-on go_home"></i>
                        <span class="color-label">LIGHT MODE</span>
                        <span class="badge light-badge mr-2 ml-2 active-badge" id="lightThemeBadge"></span>
                        <span class="badge dark-badge ml-2 mr-2" id="darkThemeBadge"></span>
                        <span class="color-label">DARK MODE</span>
                    </li>
                </ul>
            </div>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer class="copyright text-center p-4 bg-white mt-5 position-sticky sticky_footer custom-footer-width">
        <?php echo $__env->make('layouts.web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>
<?php else: ?>
    <!-- main part starts -->
    <main class="main-page w-100" id="webApp">
        <div class="fixed-plugin">
            <div class="click_show">
                <a href="#/" data-toggle="dropdown" aria-expanded="true">
                    <i class="fa fa-cog"></i>
                </a>
                <ul class="dropdown-menu show">
                    <li class="adjustments-line text-center">
                            <i class="fas fa-toggle-on go_home"></i>
                        <span class="color-label">LIGHT MODE</span>
                        <span class="badge light-badge mr-2 ml-2 active-badge" id="lightThemeBadge"></span>
                        <span class="badge dark-badge ml-2 mr-2" id="darkThemeBadge"></span>
                        <span class="color-label">DARK MODE</span>
                    </li>
                </ul>
            </div>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer class="copyright text-center p-4 bg-white w-100 web-side-footer">
        <?php echo $__env->make('layouts.web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>
<?php endif; ?>

<?php echo $__env->make('layouts.web.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('page_js'); ?>
<?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/web/app.blade.php ENDPATH**/ ?>