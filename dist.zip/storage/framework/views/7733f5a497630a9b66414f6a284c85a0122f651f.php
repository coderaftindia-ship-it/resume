<?php $__env->startSection('title'); ?>
    LogIn
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="login-page">
        <!-- Page content -->
        <div class="container">
            <!-- Header -->
            <div class="header">
                <div class="container">
                    <div class="header-body text-center mb-4">
                        <div class="row justify-content-center d-flex align-items-center">
                            <a href="<?php echo e(route('front')); ?>" class="d-flex">
                                <img class="navbar-brand-img login-img object-cover mr-2 mb-0 login-logo"
                                     src="<?php echo e(getAdminSettingValue('company_logo')); ?>"
                                     width="65" height="35" alt="Infyom Logo"/>
                                <h1 class="text-dark mb-0"><?php echo e(getAdminSettingValue('company_name')); ?></h1>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-5 col-md-7">
                    <div class="card login-card border-0 mb-0">
                        <div class="card-body px-lg-5 py-lg-5">
                            <div class="text-center login-heading">
                                <h1 class="text-dark login-sign mb-2">Sign In to Portfolio</h1>
                                <div class="login-text">New Here?
                                    <a href="<?php echo e(route('user.register')); ?>" class="link-primary login-link">Create an Account</a></div>
                            </div>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger p-0 custom_alert">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="mt-3"><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(!empty(session('message'))): ?>
                                <div class="alert alert-danger py-3">
                                    <span><?php echo e(session('message')); ?></span>
                                    <form class="d-inline float-right" method="GET"
                                          action="<?php echo e(route('resend.verification.email')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="user-email" value="<?php echo e(session('userEmail')); ?>">
                                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline"
                                                title="Resend Verification Email">
                                            <i class="fa fa-envelope text-white"></i>
                                        </button>
                                    </form>
                                </div>
                            <?php endif; ?>
                            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="text-center text-muted mb-4"></div>
                            <form method="POST" action="<?php echo e(route('login')); ?>" id="loginForm">
                                <?php echo csrf_field(); ?>
                                <div class="form-group mb-4 email-section">
                                    <label class="form-label text-dark custom-label">Email:</label><span
                                            class="text-danger">* </span>
                                    <div>
                                        <input type="email" class="form-control <?php echo e($errors->any()?'is-invalid':''); ?>"
                                               name="email" tabindex="1" placeholder="Email" required id="email"
                                               value="<?php echo e((Cookie::get('email') !== null) ? Cookie::get('email') : old('email')); ?>">
                                    </div>
                                    <div class="invalid-feedback">
                                        <?php echo e($errors->first('email')); ?>

                                    </div>
                                </div>
                                <div class="form-group password-section">
                                    <div class="d-flex justify-content-between">
                                        <label class="form-label text-dark custom-label">Password:<span
                                                    class="text-danger login-star">*</span></label>
                                        <a href="<?php echo e(route('password.request')); ?>" class="link-primary"><small
                                                    class="custom-link">Forgot password ?</small></a>
                                    </div>
                                    <div>
                                        <input class="form-control password <?php echo e($errors->has('password') ? ' is-invalid': ''); ?>"
                                               placeholder="Password" type="password" name="password" required
                                               value="<?php echo e((Cookie::get('password') !== null) ? Cookie::get('password') : null); ?>"
                                               tabindex="2">
                                    </div>
                                    <div class="invalid-feedback">
                                        <?php echo e($errors->first('password')); ?>

                                    </div>
                                </div>
                                <div class="custom-control custom-control-alternative custom-checkbox mb-3">
                                    <input type="checkbox" name="remember" class="custom-control-input" tabindex="3"
                                           id="remember" <?php echo e((Cookie::get('remember') !== null) ? 'checked' : ''); ?>>
                                    <label class="custom-control-label" for="remember">
                                        <span class="text-muted">Remember me</span>
                                    </label>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary w-100" id="btnLogin"
                                            data-loading-text="<span class='spinner-border spinner-border-sm'></span> Processing...">
                                        Sign in
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page_js'); ?>
    <script>
        let hasUserEmailVerified = "<?php echo e(session('verifyEmail')); ?>";
        <?php if(empty(session('message'))): ?>
        setTimeout(function () { $('.alert').slideUp(500); }, 3000);
        <?php endif; ?>
    </script>
    <script src="<?php echo e(mix('assets/js/login/login.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/auth/login.blade.php ENDPATH**/ ?>