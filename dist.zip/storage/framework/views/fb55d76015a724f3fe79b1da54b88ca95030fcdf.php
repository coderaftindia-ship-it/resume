<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(mix('assets/web/js/slick.min.js')); ?>"></script>
<script src="<?php echo e(mix('assets/web/js/script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/iziToast.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(mix('assets/js/custom/custom.js')); ?>"></script>

<!-- aos script  -->
<script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
<script src="<?php echo e(mix('assets/js/web/app/app.js')); ?>"></script>
<?php /**PATH /Applications/MAMP/htdocs/InfyProducts/infy-portfolio/resources/views/layouts/web/js.blade.php ENDPATH**/ ?>