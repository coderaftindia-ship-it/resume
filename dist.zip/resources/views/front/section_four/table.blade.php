<table class="table table-responsive table-striped table-bordered datatable-table" id="sectionFourTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.front_side_cms.s3_image_one')}}</th>
        <th scope="col">{{__('messages.front_side_cms.s3_image_text_one')}}</th>
        <th scope="col">{{__('messages.front_side_cms.s4_img_text_description')}}</th>
        <th scope="col">{{__('messages.color')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
