<table class="table table-responsive table-striped table-bordered datatable-table" id="sectionThreeTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.front_side_cms.s3_image_one')}}</th>
        <th scope="col">{{__('messages.front_side_cms.s3_text_slider_one')}}</th>
        <th scope="col">{{__('messages.front_side_cms.s3_image_text_one')}}</th>
        <th scope="col">{{__('messages.front_side_cms.s3_image_text_one_secondary')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
