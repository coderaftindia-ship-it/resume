<table class="table table-responsive-sm table-striped table-bordered datatable-table" id="sectionFiveTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.front_side_cms.s5_main_text')}}</th>
        <th scope="col">{{__('messages.front_side_cms.text_secondary')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
