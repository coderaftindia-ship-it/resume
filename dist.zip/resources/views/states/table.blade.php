<table class="table table-responsive-sm table-striped table-bordered datatable-table" id="statesTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.states.name')}}</th>
        <th scope="col">{{__('messages.states.country_id')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
