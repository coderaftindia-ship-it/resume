<table class="table table-responsive-sm table-striped table-bordered datatable-table" id="countriesTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.countries.name')}}</th>
        <th scope="col">{{__('messages.countries.short_code')}}</th>
        <th scope="col">{{__('messages.countries.phone_code')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
