 <table class="table table-responsive table-striped table-bordered datatable-table" id="hireMeTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.name')}}</th>
        <th scope="col">{{__('messages.email')}}</th>
        <th scope="col">{{__('messages.hire_request.mobile')}}</th>
        <th scope="col">{{__('messages.hire_request.interested_in')}}</th>
        <th scope="col">{{__('messages.hire_request.budget')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
