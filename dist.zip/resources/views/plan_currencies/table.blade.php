<table class="table table-responsive table-striped table-bordered datatable-table" id="PlanCurrencyTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.pricing_plan_currency.currency_name')}}</th>
        <th scope="col">{{__('messages.pricing_plan_currency.currency_code')}}</th>
        <th scope="col">{{__('messages.pricing_plan_currency.currency_icon')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
