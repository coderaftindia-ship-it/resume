<table class="table table-responsive table-striped table-bordered datatable-table" id="enquiriesTable">
    <thead>
    <tr>
        <th>{{__('messages.name')}}</th>
        <th>{{__('messages.email')}}</th>
        <th>{{__('messages.enquiries.received_on')}}</th>
        <th>{{__('messages.enquiries.status')}}</th>
        <th>{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
