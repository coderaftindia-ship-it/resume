<table class="table table-responsive table-striped table-bordered datatable-table" id="achievementTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.title')}}</th>
        <th scope="col">{{__('messages.icon')}}</th>
        <th scope="col">{{__('messages.achievement.dark_icon')}}</th>
        <th scope="col">{{__('messages.color')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
