<table class="table table-responsive-sm table-striped table-bordered datatable-table" id="recentWorkTypeTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.name')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
