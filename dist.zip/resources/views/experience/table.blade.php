<table class="table table-responsive table-striped table-bordered datatable-table" id="experiencesTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.job_title')}}</th>
        <th scope="col">{{__('messages.start_date')}}</th>
        <th scope="col">{{__('messages.end_date')}}</th>
        <th scope="col">{{__('messages.work_here')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
