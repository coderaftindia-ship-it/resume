@extends('errors::minimal')

@section('title', __('messages.errors.forbidden'))
@section('code', '403')
@section('title', __('messages.errors.forbidden'))
