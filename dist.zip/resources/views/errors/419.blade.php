@extends('errors::minimal')

@section('title', __('messages.errors.page_expire'))
@section('code', '419')
@section('message', __('messages.errors.page_expire'))
