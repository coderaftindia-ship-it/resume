@extends('errors::minimal')

@section('title', __('messages.errors.service_unavailable'))
@section('code', '503')
@section('message', __('messages.errors.service_unavailable'))
