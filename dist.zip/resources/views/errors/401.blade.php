@extends('errors::minimal')

@section('title', __('messages.errors.unauthorized'))
@section('code', '401')
@section('title', __('messages.errors.unauthorized'))
