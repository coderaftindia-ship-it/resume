<table class="table table-responsive table-striped table-bordered datatable-table" id="educationsTable">
    <thead>
    <tr>
        <th>{{__('messages.school_name')}}</th>
        <th>{{__('messages.qualification')}}</th>
        <th>{{__('messages.start_date')}}</th>
        <th>{{__('messages.end_date')}}</th>
        <th>{{__('messages.study_here')}}</th>
        <th>{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
