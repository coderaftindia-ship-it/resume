<table class="table table-responsive table-striped table-bordered datatable-table" id="skillsTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.name')}}</th>
        <th scope="col">{{__('messages.percentage')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
