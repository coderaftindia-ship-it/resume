<table class="table table-responsive table-striped table-bordered datatable-table" id="usersTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.admin_users.profile')}}</th>
        <th scope="col">{{__('messages.admin_users.name')}}</th>
        <th scope="col">{{__('messages.admin_users.email')}}</th>
        <th scope="col">{{__('messages.admin_users.user_name')}}</th>
        <th scope="col">{{__('messages.enquiries.status')}}</th>
        <th scope="col">{{__('messages.email_verified_at')}}</th>
        <th scope="col">{{__('messages.admin_users.impersonate')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
