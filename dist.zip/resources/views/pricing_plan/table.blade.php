<table class="table table-responsive table-striped table-bordered datatable-table" id="pricingPlansTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.image')}}</th>
        <th scope="col">{{__('messages.name')}}</th>
        <th scope="col">{{__('messages.price')}}</th>
        <th scope="col">{{__('messages.plan_type')}}</th>
        <th scope="col">{{__('messages.type')}}</th>
        <th scope="col">{{__('messages.color')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
