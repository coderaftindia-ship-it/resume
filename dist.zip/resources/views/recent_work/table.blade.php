<table class="table table-responsive table-striped table-bordered datatable-table" id="recentWorkTable">
    <thead>
    <tr>
        <th scope="col">{{__('messages.attachments')}}</th>
        <th scope="col">{{__('messages.type')}}</th>
        <th scope="col">{{__('messages.title')}}</th>
        <th scope="col">{{__('messages.link')}}</th>
        <th scope="col">{{__('messages.action')}}</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
