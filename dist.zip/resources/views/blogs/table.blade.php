<table class="table table-responsive-sm table-striped table-bordered datatable-table" id="blogsTable">
    <thead>
    <tr>
        <th scope="col">Image</th>
        <th scope="col">Title</th>
        <th scope="col">Category</th>
        <th scope="col">Action</th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
