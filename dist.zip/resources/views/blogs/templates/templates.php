<script id="bogsTemplate" type="text/x-jsrender">
   <a title="Edit" class="btn btn-default btn-icon-only-action rounded-circle edit-btn" href="{{:url}}">
            <span class="btn-inner--icon"><i class="fa fa-edit"></i></span>
   </a>
   <a title="Delete" class="btn btn-danger btn-icon-only-action rounded-circle delete-btn" data-id="{{:id}}" href="#">
            <span class="btn-inner--icon"><i class="fa fa-trash"></i></span>
   </a>


</script>
