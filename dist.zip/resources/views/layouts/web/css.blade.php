<!-- Fonts -->
{{--<link href="//fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">--}}
<link rel="stylesheet" href="{{ asset('assets/css/bootstrap.min.css') }}"  type="text/css"/>
<link rel="stylesheet" href="{{ asset('assets/css/font-awesome.min.css') }}">

<!-- slick slider css  -->
<link rel="stylesheet" href="{{asset('assets/web/css/slick.css')}}"/>
<link rel="stylesheet" href="{{asset('assets/web/css/slick-theme.css')}}"/>

<link rel="stylesheet" href="{{ asset('assets/css/sweetalert2.css') }}"  type="text/css"/>
<link rel="stylesheet" href="{{ asset('assets/css/iziToast.min.css') }}">

<!-- style  -->
<link rel="stylesheet" href="{{asset('assets/web/css/header.css')}}"/>
<link rel="stylesheet" href="{{asset('assets/web/css/home.css')}}"/>
<link rel="stylesheet" href="{{asset('assets/web/css/fonts.css')}}"/>
<link rel="stylesheet" href="{{asset('assets/web/css/variable.css')}}"/>
<link rel="stylesheet" href="{{asset('assets/web/css/blog.css')}}"/>
<link rel="stylesheet" href="{{asset('assets/web/css/blog-detail.css')}}"/>
<link rel="stylesheet" href="{{asset('assets/web/css/mixin.css')}}"/>
<link rel="stylesheet" href="{{asset('assets/web/css/scrollbar.css')}}"/>
<link rel="stylesheet" href="{{asset('assets/web/css/dark-theme.css')}}"/>
<link rel="stylesheet" href="{{asset('assets/web/css/layout.css')}}"/>
<link rel="stylesheet" href="{{asset('css/layout.css')}}"/>
<link rel="stylesheet" href="{{ asset('assets/css/web/style.css') }}">


<!-- aos animation  -->
<link rel="stylesheet" href="{{ asset('assets/css/aos.css') }}">
<link href="{{ asset('assets/css/phone-number-code.css') }}" rel="stylesheet" type="text/css" />
