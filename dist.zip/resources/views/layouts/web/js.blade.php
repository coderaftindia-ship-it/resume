<script src="{{ asset('assets/js/jquery.min.js') }}"></script>
<script src="{{mix('assets/web/js/slick.min.js')}}"></script>
<script src="{{mix('assets/web/js/script.js')}}"></script>
<script src="{{ asset('assets/js/popper.min.js') }}"></script>
<script src="{{ asset('assets/js/iziToast.min.js') }}"></script>
<script src="{{ asset('assets/js/sweetalert2.all.min.js') }}"></script>
<script src="{{ asset('assets/js/bootstrap.min.js') }}"></script>
<script src="{{asset('assets/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{ mix('assets/js/custom/custom.js') }}"></script>

<!-- aos script  -->
<script src="{{ asset('assets/js/aos.js') }}"></script>
<script src="{{ mix('assets/js/web/app/app.js') }}"></script>
